function fun= crosscorrelationthroughoutdsp(x1, x2)
    xcorr = dsp.Crosscorrelator;
    fun = xcorr(x1, x2);
end