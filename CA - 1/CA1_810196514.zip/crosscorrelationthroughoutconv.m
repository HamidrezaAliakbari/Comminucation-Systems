function fun = crosscorrelationthroughoutconv(x1, x2)
    fun = conv(x1, conj(x2(end : -1 : 1)));
end